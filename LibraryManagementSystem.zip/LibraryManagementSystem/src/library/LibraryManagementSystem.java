package library;

import library.exceptions.*;

import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        try {
            library = Library.loadLibraryData("libraryData.dat");
            System.out.println("Library data loaded successfully!");
        } catch (Exception e) {
            System.out.println("Starting a new library.");
        }

        while (true) {
            System.out.println("\n1. Add Book\n2. Display Books\n3. Add Member\n4. Issue Book\n5. Return Book\n6. Save and Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter book title: ");
                        String title = scanner.nextLine();

                        System.out.print("Enter author: ");
                        String author = scanner.nextLine();

                        System.out.print("Enter ISBN: ");
                        String ISBN = scanner.nextLine();

                        Book newBook = new Book(title, author, ISBN);
                        library.addBook(newBook);
                        System.out.println("Book added successfully!");
                    }
                    case 2 -> library.displayBooks();
                    case 3 -> {
                        System.out.print("Enter member name: ");
                        String name = scanner.nextLine();

                        System.out.print("Enter contact number: ");
                        String contact = scanner.nextLine();

                        System.out.print("Enter member ID: ");
                        int memberId = scanner.nextInt();

                        Member newMember = new Member(name, contact, memberId);
                        library.addMember(newMember);
                        System.out.println("Member added successfully!");
                    }
                    case 4 -> {
                        System.out.print("Enter member ID: ");
                        int memberId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        System.out.print("Enter book ISBN to issue: ");
                        String ISBN = scanner.nextLine();

                        Member member = library.getMemberById(memberId);
                        if (member != null) {
                            library.issueBook(member, ISBN);
                        } else {
                            System.out.println("Member not found!");
                        }
                    }
                    case 5 -> {
                        System.out.print("Enter member ID: ");
                        int memberId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        System.out.print("Enter book ISBN to return: ");
                        String ISBN = scanner.nextLine();

                        System.out.print("Enter number of days kept: ");
                        int daysKept = scanner.nextInt();

                        Member member = library.getMemberById(memberId);
                        if (member != null) {
                            library.returnBook(member, ISBN, daysKept);
                        } else {
                            System.out.println("Member not found!");
                        }
                    }
                    case 6 -> {
                        library.saveLibraryData("libraryData.dat");
                        System.out.println("Library data saved. Exiting...");
                        return;
                    }
                    default -> System.out.println("Invalid choice! Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
