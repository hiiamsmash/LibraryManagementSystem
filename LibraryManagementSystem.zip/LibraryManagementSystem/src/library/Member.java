package library;

import java.io.Serializable;

public class Member implements Serializable {
    private String name;
    private String contact;
    private int memberId;
    private int penaltyPoints = 0;

    public Member(String name, String contact, int memberId) {
        this.name = name;
        this.contact = contact;
        this.memberId = memberId;
    }

    public String getName() { return name; }
    public int getMemberId() { return memberId; }
    public int getPenaltyPoints() { return penaltyPoints; }

    public void addPenalty(int daysOverdue) {
        this.penaltyPoints += daysOverdue;
    }

    @Override
    public String toString() {
        return "Member ID: " + memberId + ", Name: " + name + ", Contact: " + contact + ", Penalty Points: " + penaltyPoints;
    }
}
