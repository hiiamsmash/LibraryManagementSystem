package library;

import library.exceptions.*;

import java.io.*;
import java.util.*;

public class Library implements Serializable {
    private HashMap<String, Book> books = new HashMap<>();
    private ArrayList<Member> members = new ArrayList<>();
    private HashMap<Member, Book> issuedBooks = new HashMap<>();

    public void addBook(Book book) {
        books.put(book.getISBN(), book);
        System.out.println("Book added successfully!");
    }

    public void displayBooks() {
        if (books.isEmpty()) System.out.println("No books available!");
        books.values().forEach(System.out::println);
    }

    public void addMember(Member member) {
        members.add(member);
        System.out.println("Member added successfully!");
    }

    public void issueBook(Member member, String ISBN) throws BookNotAvailableException {
        Book book = books.get(ISBN);

        if (book == null) throw new BookNotAvailableException("Book not found!");

        if (book.isIssued()) throw new BookNotAvailableException("Book is already issued!");

        book.issue();
        issuedBooks.put(member, book);
        System.out.println("Book issued to " + member.getName());
    }

    public void returnBook(Member member, String ISBN, int daysKept) throws BookNotIssuedException {
        if (!issuedBooks.containsKey(member)) throw new BookNotIssuedException("No book issued to this member!");

        Book book = issuedBooks.get(member);
        if (!book.getISBN().equals(ISBN)) throw new BookNotIssuedException("This book wasn't issued to this member.");

        book.returnBook();
        issuedBooks.remove(member);

        if (daysKept > 7) {
            int overdueDays = daysKept - 7;
            member.addPenalty(overdueDays);
            System.out.println("Returned with " + overdueDays + " days overdue. Penalty added.");
        } else {
            System.out.println("Book returned successfully!");
        }
    }

    public void saveLibraryData(String filename) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(this);
            System.out.println("Library data saved!");
        }
    }

    public static Library loadLibraryData(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            return (Library) in.readObject();
        }
    }
    public Member getMemberById(int memberId) {
        for (Member member : members) {
            if (member.getMemberId() == memberId) {
                return member;
            }
        }
        return null;  // Return null if member not found
    }

}
