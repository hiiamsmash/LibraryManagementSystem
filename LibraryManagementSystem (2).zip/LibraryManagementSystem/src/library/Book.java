package library;



import java.io.Serializable;
import java.time.LocalDate;

public class Book implements Serializable {
    private String title;
    private String author;
    private String ISBN;
    private boolean isIssued;
    private LocalDate issueDate;

    public Book(String title, String author, String ISBN) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.isIssued = false;
        this.issueDate = null;
    }

    public String getTitle() {
        return title;
    }

    public boolean isIssued() {
        return isIssued;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void issue(LocalDate issuedDate) {
        this.isIssued = true;
        this.issueDate = issuedDate;
    }

    public void returnBook() {
        this.isIssued = false;
        this.issueDate = null;
    }

    @Override
    public String toString() {
        return title + " by " + author + " (ISBN: " + ISBN + ")";
    }
}
