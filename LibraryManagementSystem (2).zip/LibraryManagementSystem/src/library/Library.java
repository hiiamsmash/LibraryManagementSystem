package library;

import library.exceptions.BookNotAvailableException;
import library.exceptions.BookNotIssuedException;

import java.io.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class Library implements Serializable {
    private HashMap<String, Book> books = new HashMap<>();
    private ArrayList<Member> members = new ArrayList<>();
    private HashMap<Member, ArrayList<Book>> issuedBooks = new HashMap<>();

    public void addBook(Book book) {
        books.put(book.getTitle().toLowerCase(), book);
        System.out.println("Book added successfully!");
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available!");
            return;
        }
        int count = 1;
        for (Book book : books.values()) {
            System.out.println("Book " + count + ": " + book);
            count++;
        }
    }

    public void addMember(Member member) {
        members.add(member);
        System.out.println("Member added successfully!");
    }

    public ArrayList<Member> getMembers() {
        return members;
    }

    public ArrayList<Book> getBooks() {
        ArrayList<Book> availableBooks = new ArrayList<>();
        for (Book b : books.values()) {
            if (!b.isIssued()) {
                availableBooks.add(b);
            }
        }
        return availableBooks;
    }

    public void issueBook(Member member, Book book, LocalDate issuedDate) throws BookNotAvailableException {
        if (book.isIssued()) {
            throw new BookNotAvailableException("This book is already issued!");
        }
        book.issue(issuedDate);
        issuedBooks.computeIfAbsent(member, k -> new ArrayList<>());
        issuedBooks.get(member).add(book);
        System.out.println("Book issued to " + member.getName() + " on " + book.getIssueDate());
    }

    public void returnBook(Member member, Book book) throws BookNotIssuedException {
        if (!issuedBooks.containsKey(member) || !issuedBooks.get(member).contains(book)) {
            throw new BookNotIssuedException("This book was not issued to " + member.getName());
        }

        LocalDate returnDate = LocalDate.now();
        LocalDate issueDate = book.getIssueDate();
        long daysKept = ChronoUnit.DAYS.between(issueDate, returnDate);
        int penaltyDays = (daysKept > 7) ? (int) (daysKept - 7) : 0;
        member.addPenalty(penaltyDays);

        book.returnBook();
        issuedBooks.get(member).remove(book);

        System.out.println("Book returned by " + member.getName() + " on " + returnDate);
        if (penaltyDays > 0) {
            System.out.println("Overdue by " + penaltyDays + " days. Penalty added!");
        } else {
            System.out.println("Returned on time. No penalty.");
        }
    }

    public void saveLibraryData(String filename) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(this);
            System.out.println("Library data saved!");
        }
    }

    public static Library loadLibraryData(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            return (Library) in.readObject();
        }
    }

    public HashMap<Member, ArrayList<Book>> getIssuedBooks() {
        return issuedBooks;
    }

}
