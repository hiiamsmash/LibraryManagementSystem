package library;

import library.exceptions.BookNotAvailableException;
import library.exceptions.BookNotIssuedException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        try {
            library = Library.loadLibraryData("libraryData.dat");
            System.out.println("Library data loaded successfully!");
        } catch (Exception e) {
            System.out.println("Starting a new library.");
        }

        while (true) {
            System.out.println("\n1. Add Book\n2. Display Books\n3. Add Member\n4. Issue Book\n5. Return Book\n6. Save and Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter book title: ");
                        String title = scanner.nextLine();
                        System.out.print("Enter author: ");
                        String author = scanner.nextLine();
                        System.out.print("Enter ISBN: ");
                        String ISBN = scanner.nextLine();
                        library.addBook(new Book(title, author, ISBN));
                    }
                    case 2 -> library.displayBooks();
                    case 3 -> {
                        System.out.print("Enter member name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter contact: ");
                        String contact = scanner.nextLine();
                        System.out.print("Enter member ID: ");
                        int memberId = scanner.nextInt();
                        library.addMember(new Member(name, contact, memberId));
                    }
                    case 4 -> {
                        System.out.print("Enter Member Name: ");
                        String memberName = scanner.nextLine();
                        System.out.print("Enter Book Title to Issue: ");
                        String bookTitle = scanner.nextLine();
                        System.out.print("Enter Issued Date (yyyy-MM-dd): ");
                        LocalDate issuedDate = LocalDate.parse(scanner.nextLine(), DateTimeFormatter.ISO_LOCAL_DATE);

                        Book book = library.getBooks().stream().filter(b -> b.getTitle().equalsIgnoreCase(bookTitle)).findFirst().orElse(null);
                        Member member = library.getMembers().stream().filter(m -> m.getName().equalsIgnoreCase(memberName)).findFirst().orElse(null);

                        if (book != null && member != null) {
                            library.issueBook(member, book, issuedDate);
                        } else {
                            System.out.println("Invalid book or member!");
                        }
                    }
                    case 5 -> {
                        System.out.print("Enter Member Name: ");
                        String memberName = scanner.nextLine();

                        // Find the existing member from the issuedBooks map
                        Member member = library.getMembers().stream()
                                .filter(m -> m.getName().equalsIgnoreCase(memberName))
                                .findFirst()
                                .orElse(null);

                        if (member == null || !library.getIssuedBooks().containsKey(member)) {
                            System.out.println("Member not found or has not issued any books!");
                            break;
                        }

                        System.out.print("Enter Book Title to Return: ");
                        String bookTitle = scanner.nextLine();

                        // Find the book from the issued books of the member
                        Book book = library.getIssuedBooks().get(member).stream()
                                .filter(b -> b.getTitle().equalsIgnoreCase(bookTitle))
                                .findFirst()
                                .orElse(null);

                        if (book == null) {
                            System.out.println("Book not found in issued books!");
                        } else {
                            library.returnBook(member, book);
                        }
                    }

                    case 6 -> {
                        library.saveLibraryData("libraryData.dat");
                        return;
                    }
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
